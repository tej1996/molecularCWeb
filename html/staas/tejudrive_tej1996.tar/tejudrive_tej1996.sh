rmdir /media/tejudrive_tej1996
 sudo
mkdir /media/tejudrive_tej1996
 sudo
read -p "Enter your username: " user_name
 sudo
mount //192.168.122.152/tejudrive_tej1996  /media/tejudrive_tej1996 -o username=$user_name
 sudo
