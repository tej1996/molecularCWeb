read -p "Enter Your username: "  username
ssh -X $username@192.168.122.152 firefox
